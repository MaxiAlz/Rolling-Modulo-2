class People {
  constructor(name, age, dni, sex, dateOfBirth, height, weight){
    this.name = name;
    this.age = parseInt(age);
    this.dni = dni;
    this.sex = sex;
    this.dateOfBirth = dateOfBirth;
    this.height = height;
    this.weight = weight;
  }
  showGen (){
    if (this.dateOfBirth >= 1930 && this.dateOfBirth <= 1948) {
      alert(`${this.name} pertenece a "Silent Generation" (niños de la post guerra).\n
      Su rasgo característico es la Austeridad. (Sencillez y moderación propias de la persona.).`)
    } else if(this.dateOfBirth >= 1949 && this.dateOfBirth <= 1968){
      alert(`${this.name} pertenece a "Baby Boom".\n
      Su rasgo característico es la Ambicion. (Deseo intenso y vehemente de conseguir una cosa difícil de lograr, especialmente riqueza, poder o fama.).`)
    } else if (this.dateOfBirth >= 1969 && this.dateOfBirth <= 1980) {
      alert(`${this.name} pertenece a "Generación X".\n
      Su rasgo característico es la Obsesión por el éxito. (Una competencia por alcanzar el éxito, el éxito para algunos a menudo puede variar segun su realidad.).`)
    } else if (this.dateOfBirth >= 1981 && this.dateOfBirth <= 1993) {
      alert(`${this.name} pertenece a "Generación Y".\n
      Su rasgo característico es la Frustración. (La frustración es una respuesta emocional común a la oposición, relacionada con la ira y la decepción, que surge de la percepción de resistencia al cumplimiento de la voluntad individual.).`)
    } else if (this.dateOfBirth >= 1994 && this.dateOfBirth <= 2021) {
      alert(`${this.name} pertenece a "Generación Z".\n
      Su rasgo característico es la Irreverencia. (Persona que lucha, contiende o está en oposición con otra.).`)
    }
  }

  isAdult (){
    if (this.age >= 18) {
      alert(`${this.name} es mayor de edad. \n
      Su edad actual es de ${this.age}`)
    } else {
      alert(`${this.name} NO es mayor de edad. \n
      Su edad actual es de ${this.age}`)
    }
  }

  showInfo (){
    alert(`Datos de la persona: \n
    Nombre: ${this.name}.\n
    Edad: ${this.age}.\n
    DNI: ${this.dni}.\n
    Sexo: ${this.sex}.\n
    Peso: ${this.weight}.\n
    Altura: ${this.height}.\n
    Fecha de nacimiento: ${this.dateOfBirth}.\n`)
  }

  generateId (){
    this.dni = Math.round(Math.random() * 100000000);
    alert(`Tu nuevo DNI aleatorio es ${this.dni}.`)
  }
}
let persona = null;
const ej2 = () => {
  let name = document.getElementById("name").value,
  age = document.getElementById("age").value,
  dni = document.getElementById("dni").value,
  sex = document.getElementById("sex").value,
  weight = document.getElementById("weight").value,
  height = document.getElementById("height").value,
  dateOfBirth = document.getElementById("dateOfBirth").value;
  persona = new People(name, age, dni, sex, dateOfBirth, height, weight)
  console.log(persona)
}

const ej2Metodos = (metod) => {
  persona[metod]();
};
